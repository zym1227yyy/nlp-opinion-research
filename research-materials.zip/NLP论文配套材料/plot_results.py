"""Plot the computed simulation results; not real social-media observations."""
import argparse,csv,json,os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path.cwd()/'.plot-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties,fontManager

def plot(results,out):
    out.mkdir(parents=True,exist_ok=True)
    available={x.name for x in fontManager.ttflist}
    choices=['Microsoft YaHei','SimHei','Noto Sans CJK SC','PingFang SC','WenQuanYi Micro Hei']
    chosen=next((x for x in choices if x in available),None)
    if chosen:plt.rcParams['font.family']=chosen
    plt.rcParams['axes.unicode_minus']=False
    with (results/'results_daily.csv').open(encoding='utf-8-sig') as f:daily=list(csv.DictReader(f))
    summary=json.loads((results/'results_summary.json').read_text(encoding='utf-8'))
    days=[int(r['day']) for r in daily]
    fig,ax=plt.subplots(2,1,figsize=(8,6),sharex=True,layout='constrained')
    ax[0].plot(days,[float(r['heat_equal']) for r in daily],marker='o',label='等权热度' if chosen else 'Equal weights')
    ax[0].plot(days,[float(r['heat_entropy']) for r in daily],marker='s',label='熵权热度' if chosen else 'Entropy weights')
    ax[0].plot(days,[float(r['volume_index']) for r in daily],ls='--',color='gray',label='纯数量指数' if chosen else 'Volume only')
    ax[0].set_ylabel('相对指数' if chosen else 'Relative index');ax[0].legend(ncol=3,fontsize=9);ax[0].grid(alpha=.25)
    for k,label in [('negative_share','模型负向占比' if chosen else 'Predicted negative'),('design_negative_share','设计负向占比' if chosen else 'Designed negative')]:
        ax[1].plot(days,[100*float(r[k]) for r in daily],marker='o',label=label)
    ax[1].set_xlabel('模拟日' if chosen else 'Simulated day');ax[1].set_ylabel('占比 %' if chosen else 'Share %');ax[1].set_xticks(days);ax[1].legend(ncol=2,fontsize=9);ax[1].grid(alpha=.25)
    fig.suptitle('教学模拟数据的讨论热度与负向占比' if chosen else 'Synthetic discussion indices and negative shares',fontsize=13)
    fig.savefig(out/'daily_trends.png',dpi=200);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.5,3.8),layout='constrained');xs=[0,1,2];w=.24
    settings=[('bigram_tfidf','二元 TF IDF' if chosen else 'Bigram TF-IDF'),('bigram_tf','二元词频' if chosen else 'Bigram TF'),('trigram_tfidf','三元 TF IDF' if chosen else 'Trigram TF-IDF')]
    for j,(prefix,label) in enumerate(settings):
        values=[next(r['similarity'] for r in summary['sensitivity'] if r['setting']==prefix+'_'+p) for p in ['萌芽','集中讨论','回落']]
        ax.bar([x+(j-1)*w for x in xs],values,width=w,label=label)
    ax.set_xticks(xs,['萌芽','集中讨论','回落'] if chosen else ['Early','Concentrated','Declining'])
    ax.set_ylabel('平均余弦相似度' if chosen else 'Mean cosine similarity');ax.set_ylim(0,.35);ax.legend(ncol=3,fontsize=9);ax.grid(axis='y',alpha=.2)
    ax.set_title('教学模拟数据的文本表示敏感性' if chosen else 'Text representation sensitivity in synthetic data')
    fig.savefig(out/'representation_sensitivity.png',dpi=200);plt.close(fig)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',default='results');p.add_argument('--output',default='figures');a=p.parse_args();plot(Path(a.results),Path(a.output))
